using System.Reflection; 
using System.Runtime.CompilerServices; 
using System.Runtime.InteropServices; 

//  General Information about an assembly is controlled through the following
//  set of attributes. Change these attribute values to modify the information
//  associated with an assembly





using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
[ assembly: AssemblyTitle( "USB test application for HIDs" ) ]
[ assembly: AssemblyDescription( "www.Lvr.com" ) ]
[ assembly: AssemblyCompany( "Lakeview Research" ) ]
[ assembly: AssemblyProduct( "usbhidio" ) ]
[ assembly: AssemblyCopyright( "c. 1999-2005 by Jan Axelson" ) ]
[ assembly: AssemblyTrademark( "" ) ]
[ assembly: AssemblyCulture( "" ) ]

//  Version information for an assembly consists of the following four values:

// 	Major version
// 	Minor Version
// 	Revision
// 	Build Number

//  You can specify all the values or you can default the Revision and Build Numbers
//  by using the '*' as shown below


[ assembly: AssemblyVersion( "2.2.*" ) ]



